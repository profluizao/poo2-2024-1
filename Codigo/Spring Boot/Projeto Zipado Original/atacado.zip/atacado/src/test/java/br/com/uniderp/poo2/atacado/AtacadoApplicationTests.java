package br.com.uniderp.poo2.atacado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtacadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
