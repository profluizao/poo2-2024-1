package br.com.uniderp.poo2.atacado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtacadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtacadoApplication.class, args);
	}

}
